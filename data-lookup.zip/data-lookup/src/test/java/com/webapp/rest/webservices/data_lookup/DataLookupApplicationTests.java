package com.webapp.rest.webservices.data_lookup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataLookupApplicationTests {

	@Test
	void contextLoads() {
	}

}
