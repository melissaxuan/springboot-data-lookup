package com.webapp.rest.webservices.data_lookup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataLookupApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataLookupApplication.class, args);
	}

}
